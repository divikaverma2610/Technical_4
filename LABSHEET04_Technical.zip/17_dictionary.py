student = {"name": "Alice", "age": 20}
print(student["name"])
student["age"] = 21
student["city"] = "Delhi"
print(student)