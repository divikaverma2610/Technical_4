s = input("Enter a word: ")
if s == s[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")