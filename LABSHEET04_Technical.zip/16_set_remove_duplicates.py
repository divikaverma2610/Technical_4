nums = [1, 2, 2, 3, 3, 4]
unique = list(set(nums))
print(unique)