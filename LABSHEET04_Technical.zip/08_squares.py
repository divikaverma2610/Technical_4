n = int(input("Enter N: "))
for i in range(n):
    print(i, "squared is", i*i)